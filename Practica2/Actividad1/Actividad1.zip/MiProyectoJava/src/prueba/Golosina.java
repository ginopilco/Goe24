package prueba;

public class Golosina {
private String nombre;
private double peso;

// constructor crea golosina con su nombre y peso 
public Golosina(String nombre, double peso) {
this.nombre = nombre;
this.peso = peso;
}
//metodos 
//nombre de la golosina
public String getNombre() {
return nombre;
}
//cambiar el nombre
public void setNombre(String nombre) {
this.nombre = nombre;
}
//devuelve peso de la golosina
public double getPeso() {
return peso;
}
//modificar el peso
public void setPeso(double peso) {
this.peso = peso;
}
}
