package prueba;

public class Principal {
    // crea bolsa limite 20 objetos
public static void main(String[] args) {
Bolsa bolsaChocolatinas = new Bolsa(20);
//crea chocolatinas con diferente marca
Chocolatina c = new Chocolatina("Milka");
Chocolatina c1 = new Chocolatina("Milka");
Chocolatina c2 = new Chocolatina("Ferrero");
//agrega chocolatina a la bolsa
bolsaChocolatinas.add(c);
bolsaChocolatinas.add(c1);
bolsaChocolatinas.add(c2);
//intera a la bolsa y imprime marca 
for (Object chocolatina : bolsaChocolatinas) {
System.out.println(((Chocolatina) chocolatina).getMarca());
}
}
}

